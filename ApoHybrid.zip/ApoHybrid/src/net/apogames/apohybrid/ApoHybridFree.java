//#if TreasureLogic
//@package net.apogames.apohybrid;
//@
//@public class ApoHybridFree extends ApoHybrid {
//@
//@
//@	@Override
//@	protected void onCreateApp() {
//@		ApoHybridConstants.FREE_VERSION = true;
//@		super.onCreateApp();
//@	}
//@
//@}
//#endif
